#!/bin/bash

echo "=== Phase 23 — Reporting Layer Verification ==="

BASE="$HOME/synapsis/src/synapsis/reporting"

FILES=(
  "base_reporter.py"
  "analysis_reporter.py"
  "scorecard_reporter.py"
  "timeline_reporter.py"
  "graveyard_reporter.py"
  "snapshot_reporter.py"
)

for file in "${FILES[@]}"; do
    FULL="$BASE/$file"
    echo ""
    echo "Checking: $file"

    if [ -f "$FULL" ]; then
        echo "[OK] File exists"
        if [ -s "$FULL" ]; then
            echo "     └─ file has content"
        else
            echo "     └─ file is EMPTY"
        fi
    else
        echo "[MISSING] File NOT FOUND"
        continue
    fi

    MODULE="${file/.py/}"

    python3 - <<EOF
import sys
sys.path.append("/home/wking53214/synapsis/src")
try:
    import synapsis.reporting.$MODULE
    print("     └─ import succeeded")
except Exception as e:
    print("     └─ import FAILED:", e)
EOF

done

echo ""
echo "=== Phase 23 Test Complete ==="
