#!/bin/bash

echo "=== Phase 24 — Memory Engine Verification ==="

BASE="$HOME/synapsis/src/synapsis/memory"

FILES=(
  "memory_engine.py"
  "snapshot_memory.py"
  "analysis_memory.py"
  "scorecard_memory.py"
  "timeline_memory.py"
)

for file in "${FILES[@]}"; do
    FULL="$BASE/$file"
    echo ""
    echo "Checking: $file"

    if [ -f "$FULL" ]; then
        echo "[OK] File exists"
        if [ -s "$FULL" ]; then
            echo "     └─ file has content"
        else
            echo "     └─ file is EMPTY"
        fi
    else
        echo "[MISSING] File NOT FOUND"
        continue
    fi

    MODULE="${file/.py/}"

    python3 - <<EOF
import sys
sys.path.append("/home/wking53214/synapsis/src")
try:
    import synapsis.memory.$MODULE
    print("     └─ import succeeded")
except Exception as e:
    print("     └─ import FAILED:", e)
EOF

done

echo ""
echo "=== Phase 24 Test Complete ==="
