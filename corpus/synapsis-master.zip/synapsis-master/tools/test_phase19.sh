#!/bin/bash

echo "=== Phase 19 — Models Layer Verification ==="

BASE="$HOME/synapsis/src/synapsis/models"

FILES=(
  "snapshot.py"
  "graveyard_entry.py"
  "conversation.py"
  "report.py"
  "timeline.py"
  "scorecard.py"
  "project_dna.py"
  "conversation_dna.py"
  "governance.py"
)

for file in "${FILES[@]}"; do
    FULL="$BASE/$file"
    echo ""
    echo "Checking: $file"

    if [ -f "$FULL" ]; then
        echo "[OK] File exists"
        if [ -s "$FULL" ]; then
            echo "     └─ file has content"
        else
            echo "     └─ file is EMPTY"
        fi
    else
        echo "[MISSING] File NOT FOUND"
        continue
    fi

    MODULE="${file/.py/}"

    python3 - <<EOF
import sys
sys.path.append("/home/wking53214/synapsis/src")
try:
    import synapsis.models.$MODULE
    print("     └─ import succeeded")
except Exception as e:
    print("     └─ import FAILED:", e)
EOF

done

echo ""
echo "=== Phase 19 Test Complete ==="
