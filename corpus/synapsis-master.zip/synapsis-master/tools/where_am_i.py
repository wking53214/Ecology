import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent / "src" / "synapsis"

def list_tree(root: Path):
    print(f"\n=== SYNAPSIS DIRECTORY CHECK ===\n")
    for dirpath, dirnames, filenames in os.walk(root):
        rel = Path(dirpath).relative_to(root)
        indent = "    " * len(rel.parts)
        print(f"{indent}{rel.name}/")
        for f in filenames:
            print(f"{indent}    - {f}")

def main():
    if not ROOT.exists():
        print("SYNAPSIS root not found. Check your directory structure.")
        return

    print(f"Scanning: {ROOT}")
    list_tree(ROOT)

    print("\n=== SUMMARY ===")
    print("Models layer:", (ROOT / "models").exists())
    print("Storage layer:", (ROOT / "storage").exists())
    print("Plugins layer:", (ROOT / "plugins").exists())
    print("Analysis layer:", (ROOT / "analysis").exists())
    print("Reporting layer:", (ROOT / "reporting").exists())
    print("Memory engine:", (ROOT / "memory").exists())
    print("Intelligence layer:", (ROOT / "intelligence").exists())
    print("Archaeology engine:", (ROOT / "archaeology").exists())
    print("Parser layer:", (ROOT / "parser").exists())
    print("Search engine:", (ROOT / "search").exists())
    print("Restoration engine:", (ROOT / "restoration").exists())
    print("CLI:", (ROOT / "cli").exists())

if __name__ == "__main__":
    main()
