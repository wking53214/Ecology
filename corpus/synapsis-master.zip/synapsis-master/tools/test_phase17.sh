#!/bin/bash

echo "=== Phase 17 — Data Layer Verification ==="

BASE="$HOME/synapsis/src/synapsis"

FILES=(
  "data_paths.py"
  "data/cache.py"
  "data/snapshot_store.py"
  "data/graveyard_store.py"
  "data/conversation_store.py"
  "data/report_store.py"
  "data/timeline_store.py"
)

for file in "${FILES[@]}"; do
    FULL="$BASE/$file"
    echo ""
    echo "Checking: $file"

    if [ -f "$FULL" ]; then
        echo "[OK] File exists"
        if [ -s "$FULL" ]; then
            echo "     └─ file has content"
        else
            echo "     └─ file is EMPTY (needs fixing)"
        fi
    else
        echo "[MISSING] File NOT FOUND"
        continue
    fi

    MODULE="${file/.py/}"
    MODULE="${MODULE//\//.}"

    python3 - <<EOF
import sys
sys.path.append("/home/wking53214/synapsis/src")
try:
    import synapsis.$MODULE
    print("     └─ import succeeded")
except Exception as e:
    print("     └─ import FAILED:", e)
EOF

done

echo ""
echo "=== Phase 17 Test Complete ==="
