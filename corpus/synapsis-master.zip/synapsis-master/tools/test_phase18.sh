#!/bin/bash

echo "=== Phase 18 — Configuration Layer Verification ==="

CONFIG="$HOME/synapsis/config"

FILES=(
  "defaults.yaml"
  "parser.yaml"
  "archaeology.yaml"
  "scorecard.yaml"
  "search.yaml"
  "reporting.yaml"
  "storage.yaml"
  "plugins.yaml"
  "logging.yaml"
)

for file in "${FILES[@]}"; do
    FULL="$CONFIG/$file"
    echo ""
    echo "Checking: $file"

    if [ -f "$FULL" ]; then
        echo "[OK] File exists"
        if [ -s "$FULL" ]; then
            echo "     └─ file has content"
        else
            echo "     └─ file is EMPTY (needs fixing)"
        fi
    else
        echo "[MISSING] File NOT FOUND"
    fi
done

echo ""
echo "=== Phase 18 Test Complete ==="
