#!/bin/bash

CONFIG_DIR="$HOME/synapsis/config"

echo "=== Checking Phase 18 Config Files ==="

FILES=(
  "defaults.yaml"
  "parser.yaml"
  "archaeology.yaml"
  "scorecard.yaml"
  "search.yaml"
  "reporting.yaml"
  "storage.yaml"
  "plugins.yaml"
  "logging.yaml"
)

for file in "${FILES[@]}"; do
    FULL="$CONFIG_DIR/$file"
    if [ -f "$FULL" ]; then
        echo "[OK] $file exists"
        if [ -s "$FULL" ]; then
            echo "     └─ file has content"
        else
            echo "     └─ file is EMPTY (needs fixing)"
        fi
    else
        echo "[MISSING] $file NOT FOUND"
    fi
done

echo "=== Done ==="
