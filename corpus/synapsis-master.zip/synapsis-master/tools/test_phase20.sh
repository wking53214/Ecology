#!/bin/bash

echo "=== Phase 20 — Storage Layer Verification ==="

BASE="$HOME/synapsis/src/synapsis/storage"

FILES=(
  "backend.py"
  "filesystem_backend.py"
  "manager.py"
)

for file in "${FILES[@]}"; do
    FULL="$BASE/$file"
    echo ""
    echo "Checking: $file"

    if [ -f "$FULL" ]; then
        echo "[OK] File exists"
        if [ -s "$FULL" ]; then
            echo "     └─ file has content"
        else
            echo "     └─ file is EMPTY"
        fi
    else
        echo "[MISSING] File NOT FOUND"
        continue
    fi

    MODULE="${file/.py/}"

    python3 - <<EOF
import sys
sys.path.append("/home/wking53214/synapsis/src")
try:
    import synapsis.storage.$MODULE
    print("     └─ import succeeded")
except Exception as e:
    print("     └─ import FAILED:", e)
EOF

done

echo ""
echo "=== Phase 20 Test Complete ==="
