# SYNAPSIS

SYNAPSIS is a modular, multi‑phase code intelligence engine designed to analyze, report on, and remember the structure and evolution of a software project. It provides a full pipeline including scanning, AST analysis, metric extraction, reporting, snapshotting, memory storage, and a command‑line interface.

## Features

- Repository scanning with `.gitignore` support  
- Python AST analysis  
- Symbol extraction (functions, classes, methods)  
- Metrics engine (lines, imports, structure)  
- Reporting layer (analysis, scorecard, timeline, snapshot)  
- Memory engine (persistent JSON storage)  
- Snapshot system  
- Plugin architecture  
- Full CLI (`synapsis`)  
- Configurable, extensible, and deterministic

## Installation

Clone the repository:
