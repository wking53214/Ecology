from dataclasses import dataclass
from typing import Dict, Any

@dataclass
class GovernanceRecord:
    rule: str
    status: str
    details: Dict[str, Any]
