from dataclasses import dataclass
from datetime import datetime

@dataclass
class GraveyardEntry:
    symbol: str
    file_path: str
    removed_at: datetime
    reason: str
