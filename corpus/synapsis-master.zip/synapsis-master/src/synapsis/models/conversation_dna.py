from dataclasses import dataclass
from typing import Dict, Any

@dataclass
class ConversationDNA:
    patterns: Dict[str, Any]
    metrics: Dict[str, Any]
