from dataclasses import dataclass
from typing import Dict, Any

@dataclass
class Scorecard:
    scores: Dict[str, float]
    weights: Dict[str, float]
    metadata: Dict[str, Any]
