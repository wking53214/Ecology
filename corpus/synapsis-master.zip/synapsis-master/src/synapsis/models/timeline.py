from dataclasses import dataclass
from datetime import datetime

@dataclass
class TimelineEvent:
    timestamp: datetime
    description: str

@dataclass
class Timeline:
    name: str
    events: list
