from dataclasses import dataclass
from typing import Dict, Any

@dataclass
class ProjectDNA:
    components: Dict[str, Any]
    dependencies: Dict[str, Any]
    metrics: Dict[str, Any]
