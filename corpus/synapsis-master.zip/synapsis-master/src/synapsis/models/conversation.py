from dataclasses import dataclass
from datetime import datetime
from typing import List, Dict

@dataclass
class ConversationTurn:
    role: str
    content: str
    timestamp: datetime

@dataclass
class Conversation:
    name: str
    turns: List[ConversationTurn]
