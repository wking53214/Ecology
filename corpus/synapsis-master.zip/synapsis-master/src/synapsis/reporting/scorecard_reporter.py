from synapsis.reporting.base_reporter import BaseReporter
from synapsis.models.scorecard import Scorecard
from synapsis.models.report import Report

class ScorecardReporter(BaseReporter):

    def __init__(self, scorecard: Scorecard):
        self.scorecard = scorecard

    def generate(self) -> Report:
        sections = {
            "scores": self.scorecard.scores,
            "weights": self.scorecard.weights,
            "metadata": self.scorecard.metadata
        }
        return self._make_report("scorecard_report", sections)
