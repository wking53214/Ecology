from synapsis.reporting.base_reporter import BaseReporter
from synapsis.models.graveyard_entry import GraveyardEntry
from synapsis.models.report import Report

class GraveyardReporter(BaseReporter):

    def __init__(self, entries):
        self.entries = entries

    def generate(self) -> Report:
        sections = {
            "removed_symbols": [
                {
                    "symbol": e.symbol,
                    "file": e.file_path,
                    "removed_at": e.removed_at.isoformat(),
                    "reason": e.reason
                }
                for e in self.entries
            ]
        }
        return self._make_report("graveyard_report", sections)
