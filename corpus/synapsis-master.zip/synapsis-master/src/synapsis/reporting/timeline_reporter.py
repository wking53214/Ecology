from synapsis.reporting.base_reporter import BaseReporter
from synapsis.models.timeline import Timeline
from synapsis.models.report import Report

class TimelineReporter(BaseReporter):

    def __init__(self, timeline: Timeline):
        self.timeline = timeline

    def generate(self) -> Report:
        sections = {
            "events": [
                {"timestamp": e.timestamp.isoformat(), "description": e.description}
                for e in self.timeline.events
            ]
        }
        return self._make_report("timeline_report", sections)
