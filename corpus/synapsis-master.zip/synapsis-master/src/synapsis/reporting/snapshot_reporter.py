from synapsis.reporting.base_reporter import BaseReporter
from synapsis.models.snapshot import Snapshot
from synapsis.models.report import Report

class SnapshotReporter(BaseReporter):

    def __init__(self, snapshot: Snapshot):
        self.snapshot = snapshot

    def generate(self) -> Report:
        sections = {
            "name": self.snapshot.name,
            "created_at": self.snapshot.created_at.isoformat(),
            "data": self.snapshot.data
        }
        return self._make_report("snapshot_report", sections)
