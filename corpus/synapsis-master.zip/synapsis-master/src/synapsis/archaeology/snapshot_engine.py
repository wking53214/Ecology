"""
Snapshot Engine — Phase 4
Produces snapshot_###.json for every scan.
"""
