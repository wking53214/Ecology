"""
Chat Archaeology Engine — Phase 8
Full pipeline for chat ingestion, extraction, indexing, and knowledge storage.
"""
