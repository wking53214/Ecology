"""
Graveyard — Phase 5
Tracks removed symbols, references, restoration candidates, and history.
"""
