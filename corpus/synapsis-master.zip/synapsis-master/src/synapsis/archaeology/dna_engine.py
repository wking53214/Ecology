"""
DNA Engine — Phase 3
Coordinates scanner + symbol index → project.dna.json
"""
