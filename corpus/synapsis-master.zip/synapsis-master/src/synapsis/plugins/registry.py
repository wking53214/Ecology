from typing import Dict, Any, List
from synapsis.config.loader import load_config
from synapsis.plugins.plugin_base import Plugin

class PluginRegistry:

    def __init__(self):
        config = load_config("plugins")
        enabled = config.get("plugins", {}).get("enabled", [])
        self.plugins: Dict[str, Plugin] = {}
        self._load_plugins(enabled)

    def _load_plugins(self, enabled: List[str]):
        for name in enabled:
            try:
                module = __import__(f"synapsis.plugins.{name}_plugin", fromlist=["Plugin"])
                plugin_class = getattr(module, "PluginImpl")
                plugin_instance = plugin_class()
                self.plugins[name] = plugin_instance
            except Exception as e:
                print(f"[WARN] Failed to load plugin '{name}': {e}")

    def get(self, name: str) -> Plugin | None:
        return self.plugins.get(name)

    def all(self) -> Dict[str, Plugin]:
        return self.plugins
