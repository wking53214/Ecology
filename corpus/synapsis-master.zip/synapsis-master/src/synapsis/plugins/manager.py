from typing import Dict, Any
from synapsis.plugins.registry import PluginRegistry

class PluginManager:

    def __init__(self):
        self.registry = PluginRegistry()

    def execute(self, plugin_name: str, data: Dict[str, Any]) -> Dict[str, Any]:
        plugin = self.registry.get(plugin_name)
        if not plugin:
            raise ValueError(f"Plugin '{plugin_name}' not found")
        return plugin.execute(data)

    def list_plugins(self):
        return list(self.registry.all().keys())
