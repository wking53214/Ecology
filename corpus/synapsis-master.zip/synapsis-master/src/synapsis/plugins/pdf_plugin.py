from synapsis.plugins.plugin_base import Plugin

class PluginImpl(Plugin):

    def name(self) -> str:
        return "pdf"

    def execute(self, data):
        return {"pdf": f"PDF placeholder for: {data.get('text', '')}"}
