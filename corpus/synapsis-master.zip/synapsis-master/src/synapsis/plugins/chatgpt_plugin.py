from synapsis.plugins.plugin_base import Plugin

class PluginImpl(Plugin):
    def name(self):
        return "chatgpt"

    def execute(self, data):
        return {"chatgpt": "stub plugin loaded"}
