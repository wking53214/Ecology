from synapsis.plugins.plugin_base import Plugin

class PluginImpl(Plugin):

    def name(self) -> str:
        return "markdown"

    def execute(self, data):
        text = data.get("text", "")
        return {"markdown": f"**{text}**"}
