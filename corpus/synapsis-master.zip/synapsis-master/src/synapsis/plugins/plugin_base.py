from abc import ABC, abstractmethod
from typing import Any, Dict

class Plugin(ABC):

    @abstractmethod
    def name(self) -> str:
        pass

    @abstractmethod
    def execute(self, data: Dict[str, Any]) -> Dict[str, Any]:
        pass
