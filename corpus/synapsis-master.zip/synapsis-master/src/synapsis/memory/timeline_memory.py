from synapsis.memory.memory_engine import MemoryEngine
from synapsis.models.timeline import Timeline

class TimelineMemory:

    def __init__(self):
        self.engine = MemoryEngine()

    def save_timeline(self, timeline: Timeline):
        self.engine.save("latest_timeline", {
            "events": [
                {"timestamp": e.timestamp.isoformat(), "description": e.description}
                for e in timeline.events
            ]
        })

    def load_timeline(self):
        return self.engine.load("latest_timeline")
