from synapsis.memory.memory_engine import MemoryEngine
from synapsis.models.scorecard import Scorecard

class ScorecardMemory:

    def __init__(self):
        self.engine = MemoryEngine()

    def save_scorecard(self, scorecard: Scorecard):
        self.engine.save("latest_scorecard", {
            "scores": scorecard.scores,
            "weights": scorecard.weights,
            "metadata": scorecard.metadata
        })

    def load_scorecard(self):
        return self.engine.load("latest_scorecard")
