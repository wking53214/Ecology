"""
Restoration Model — Phase 12
Defines metadata and structure for restoration candidates.
"""
