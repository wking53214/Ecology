"""
Call Graph — Phase 6
Builds a graph of function/method calls across the repository.
"""
