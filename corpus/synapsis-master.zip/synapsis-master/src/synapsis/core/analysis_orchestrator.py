"""
Analysis Orchestrator — Phase 10
Coordinates full SYNAPSIS pipeline:
scanner → index → DNA → snapshot → diff → graveyard →
interaction map → governance → knowledge graph → report.
"""
