"""
Report Model — Phase 7
Defines the immutable report schema (SPR-001).
"""
