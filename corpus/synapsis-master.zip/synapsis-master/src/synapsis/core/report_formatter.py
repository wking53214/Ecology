"""
Report Formatter — Phase 7
Renders deterministic SPR-001 reports with fixed section ordering.
"""
