"""
Symbol Index — Phase 2
Indexes classes, functions, enums, dataclasses, exceptions, APIs.
"""
