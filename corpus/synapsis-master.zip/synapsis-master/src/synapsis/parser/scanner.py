"""
Repository Scanner — Phase 16 Implementation
Discovers Python files, packages, and modules.
"""

from pathlib import Path
from dataclasses import dataclass, field

@dataclass
class FileInfo:
    path: Path
    is_package: bool
    module_name: str

@dataclass
class RepositoryInventory:
    root: Path
    files: list[FileInfo] = field(default_factory=list)

class RepositoryScanner:
    def __init__(self, root: str):
        self.root = Path(root)

    def scan(self) -> RepositoryInventory:
        inventory = RepositoryInventory(root=self.root)

        for path in self.root.rglob("*.py"):
            rel = path.relative_to(self.root)
            module_name = ".".join(rel.with_suffix("").parts)
            is_package = path.name == "__init__.py"

            inventory.files.append(
                FileInfo(
                    path=path,
                    is_package=is_package,
                    module_name=module_name,
                )
            )

        return inventory


# Test harness
if __name__ == "__main__":
    scanner = RepositoryScanner(".")
    inventory = scanner.scan()
    for f in inventory.files:
        print(f"{f.module_name} -> {f.path}")
