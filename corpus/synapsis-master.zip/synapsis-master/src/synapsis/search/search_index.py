"""
Search Index — Phase 11
Unified index across repository symbols, snapshots, graveyard, chat artifacts, and knowledge graph.
"""
