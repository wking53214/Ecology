import ast
from typing import Dict

class ASTAnalyzer:

    def analyze(self, source: str) -> Dict[str, int]:
        tree = ast.parse(source)
        lines = len(source.splitlines())
        imports = sum(isinstance(n, ast.Import) or isinstance(n, ast.ImportFrom) for n in ast.walk(tree))

        return {
            "lines": lines,
            "imports": imports
        }
