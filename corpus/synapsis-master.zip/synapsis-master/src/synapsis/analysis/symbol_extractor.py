import ast
from typing import Dict, List

class SymbolExtractor:

    def extract(self, tree: ast.AST) -> Dict[str, List[str]]:
        functions = []
        classes = []
        methods = []

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                functions.append(node.name)
            elif isinstance(node, ast.ClassDef):
                classes.append(node.name)
                for body_item in node.body:
                    if isinstance(body_item, ast.FunctionDef):
                        methods.append(f"{node.name}.{body_item.name}")

        return {
            "functions": functions,
            "classes": classes,
            "methods": methods
        }
