from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DATA_ROOT = PROJECT_ROOT / "data"

def path_for(category: str) -> Path:
    p = DATA_ROOT / category
    p.mkdir(parents=True, exist_ok=True)
    return p
