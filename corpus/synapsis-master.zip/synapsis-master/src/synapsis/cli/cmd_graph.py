"""
Graph Command — Phase 15
Explores the SYNAPSIS knowledge graph.
"""
