"""
SYNAPSIS CLI — Phase 10
Provides command-line interface for running SYNAPSIS analyses.
"""
