"""
CLI Utilities — Phase 10
Argument parsing, config loading, environment setup.
"""
