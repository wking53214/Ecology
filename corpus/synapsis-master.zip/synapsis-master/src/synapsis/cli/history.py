"""
Command History — Phase 13
Records CLI sessions, commands, and interactive exploration history.
"""
