"""
Command Router — Phase 13
Routes CLI commands to orchestrator, search engine, and knowledge graph.
"""
