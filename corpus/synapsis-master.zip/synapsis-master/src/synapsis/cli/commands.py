"""
CLI Commands — Phase 10
Defines CLI subcommands: analyze, snapshot, diff, graveyard, graph, report.
"""
