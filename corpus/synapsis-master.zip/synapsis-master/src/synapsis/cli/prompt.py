"""
CLI Prompt — Phase 13
Defines SYNAPSIS prompt appearance, colors, and interactive behavior.
"""
