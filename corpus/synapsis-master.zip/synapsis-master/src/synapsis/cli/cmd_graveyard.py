"""
Graveyard Command — Phase 15
Displays removed symbols and restoration candidates.
"""
