"""
Diff Command — Phase 15
Compares two snapshots and reports added/removed/modified symbols.
"""
