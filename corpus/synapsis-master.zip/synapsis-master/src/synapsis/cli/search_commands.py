"""
Search Commands — Phase 14
CLI interface for unified search across repository, archaeology, chat, and knowledge graph.
"""
