"""
Interactive Help System — Phase 13
Provides contextual help, command descriptions, and usage examples.
"""
