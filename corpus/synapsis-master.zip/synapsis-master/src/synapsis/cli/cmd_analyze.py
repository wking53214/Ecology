"""
Analyze Command — Phase 15
Runs full SYNAPSIS analysis pipeline.
"""
