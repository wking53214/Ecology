"""
Graveyard Commands — Phase 14
CLI interface for inspecting removed symbols and restoration candidates.
"""
