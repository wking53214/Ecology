"""
Interactive Shell — Phase 13
Provides REPL interface for SYNAPSIS commands and exploration.
"""
