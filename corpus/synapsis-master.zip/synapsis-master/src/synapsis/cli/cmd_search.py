"""
Search Command — Phase 15
Searches repository, archaeology, chat, and knowledge graph.
"""
