"""
CLI Integration Layer — Phase 14
Connects restoration, graph, timeline, graveyard, and search commands to the CLI router.
"""
