"""
Graph Commands — Phase 14
CLI interface for exploring the SYNAPSIS knowledge graph.
"""
