"""
Knowledge Graph Builder — Phase 9
Builds unified graph from repository symbols, snapshots, graveyard, and chat artifacts.
"""
