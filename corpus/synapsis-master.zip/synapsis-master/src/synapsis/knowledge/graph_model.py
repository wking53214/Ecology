"""
Knowledge Graph Model — Phase 9
Defines nodes, edges, metadata, and identity for the SYNAPSIS knowledge graph.
"""
