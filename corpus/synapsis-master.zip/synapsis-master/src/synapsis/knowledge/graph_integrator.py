"""
Knowledge Graph Integrator — Phase 9
Merges repository graph, archaeology graph, and chat graph into a single unified structure.
"""
