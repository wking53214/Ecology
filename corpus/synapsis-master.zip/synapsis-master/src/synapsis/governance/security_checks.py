"""
Security Checks — Phase 7
Analyzes unsafe APIs, validation, secrets, injection risks.
"""
