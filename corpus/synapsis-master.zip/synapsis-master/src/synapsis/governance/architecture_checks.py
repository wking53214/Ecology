"""
Architecture Checks — Phase 7
Assesses separation of concerns, layering, SOLID, cohesion.
"""
